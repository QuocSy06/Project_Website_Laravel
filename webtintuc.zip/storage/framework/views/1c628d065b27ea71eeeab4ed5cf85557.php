<div class="comments-wrap">
    <h3 class="comments-wrap-title">
        <?php echo e($post->comments->count()); ?> Bình luận
    </h3>
    <div class="latest-comments">
        <ul class="list-wrap">
            <?php if($post->comments && $post->comments->count() > 0): ?>
            <ul id="comments-list" class="list-wrap">
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="comments-box">
                            <div class="comments-avatar">
                                <img src="<?php echo e(asset('/template/assets/img/User-avatar.png')); ?>" alt="img">
                            </div>
                            <div class="comments-text">
                                <div class="avatar-name">
                                    <h6 class="name"><?php echo e($comment->user ? $comment->user->name : 'Người dùng ẩn danh'); ?></h6>
                                    <span class="date"><?php echo e($comment->created_at->locale('vi')->diffForHumans()); ?></span>
                                </div>
                                <p><?php echo e($comment->content); ?></p>
                                
                                <!-- Phần trả lời sẽ được hiển thị ở đây -->
                            </div>
                        </div>
                        
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <p>Chưa có bình luận nào.</p>
            <?php endif; ?>
        </ul>
    </div>
</div>

<div class="comment-respond">
    <h3 class="comment-reply-title">Gửi bình luận</h3>
    <?php if(Auth::check()): ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form id="comment-form" class="comment-form">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
            <div class="form-grp">
                <textarea name="content" placeholder="Ý kiến của bạn"></textarea>
            </div>
            <button type="submit" class="btn btn-two">Gửi bình luận</button>
        </form>
    <?php else: ?>
        <p class="comment-notes text-danger">
            Vui lòng <a href="<?php echo e(route('login')); ?>">đăng nhập</a> hoặc <a href="<?php echo e(route('register')); ?>">đăng ký</a> để gửi bình luận *
        </p>
    <?php endif; ?>
</div>

<!-- Trả lời bình luận -->


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
    $('#comment-form').on('submit', function(event) {
        event.preventDefault(); // Ngăn chặn gửi form mặc định

        $.ajax({
            url: '<?php echo e(route('comments.store')); ?>',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    // Hiển thị thông báo thành công
                    alertify.success(response.success);

                    // Thêm bình luận mới vào đầu danh sách bình luận
                    $('#comments-list').prepend(`
                        <li>
                            <div class="comments-box">
                                <div class="comments-avatar">
                                    <img src="<?php echo e(asset('/template/assets/img/User-avatar.png')); ?>" alt="img">
                                </div>
                                <div class="comments-text">
                                    <div class="avatar-name">
                                        <h6 class="name"><?php echo e(Auth::user()->name); ?></h6>
                                        <span class="date">Vừa xong</span>
                                    </div>
                                    <p>${response.comment.content}</p>
                                </div>
                            </div>
                        </li>
                    `);

                    // Xóa nội dung trong form
                    $('#comment-form')[0].reset();
                }
            },
            error: function(xhr) {
                var error = xhr.responseJSON;
                if (xhr.status === 401) {
                    alertify.error(error.error);
                } else {
                    alertify.error('Đã xảy ra lỗi, vui lòng thử lại.');
                }
            }
        });
    });
});


</script>


<?php /**PATH C:\OSPanel\domains\webtintuc\resources\views/comments.blade.php ENDPATH**/ ?>