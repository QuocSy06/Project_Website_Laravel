<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>News - Tin tức mới nhất hàng ngày</title>
<meta name="description" content="Zaira - News Magazine HTML Template">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="shortcut icon" type="image/x-icon" href="/template/assets/img/logo/logoIcon_Tintuc.png">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<link rel="stylesheet" href="/template/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="/template/assets/css/animate.min.css">
<link rel="stylesheet" href="/template/assets/css/magnific-popup.css">
<link rel="stylesheet" href="/template/assets/css/fontawesome-all.min.css">
<link rel="stylesheet" href="/template/assets/css/flaticon.css">
<link rel="stylesheet" href="/template/assets/css/slick.css">
<link rel="stylesheet" href="/template/assets/css/swiper-bundle.css">
<link rel="stylesheet" href="/template/assets/css/default.css">
<link rel="stylesheet" href="/template/assets/css/style.css">
<link rel="stylesheet" href="/template/assets/css/responsive.css">

{{-- Alert --}}
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs/build/css/alertify.min.css">
<script src="https://cdn.jsdelivr.net/npm/alertifyjs/build/alertify.min.js"></script>

