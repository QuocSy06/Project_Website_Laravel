<div>
    <div class="comments-wrap">
        <h3 class="comments-wrap-title">
            
        </h3>
        <div class="latest-comments">
            <ul class="list-wrap">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li>
                        <div class="comments-box">
                            <div class="comments-avatar">
                                <img src="<?php echo e(asset('/template/assets/img/User-avatar.png')); ?>" alt="img">
                            </div>
                            <div class="comments-text">
                                <div class="avatar-name">
                                    <h6 class="name"><?php echo e($comment->user ? $comment->user->name : 'Người dùng ẩn danh'); ?></h6>
                                    <span class="date"><?php echo e($comment->created_at->locale('vi')->translatedFormat('d F, Y')); ?></span>
                                </div>
                                <p><?php echo e($comment->content); ?></p>
                                <a href="#" class="reply-btn" data-comment-id="<?php echo e($comment->id); ?>">Trả lời</a>
                                <!-- Phần trả lời sẽ được hiển thị ở đây -->
                            </div>
                        </div>
                        <ul class="children">
                            <!--[if BLOCK]><![endif]--><?php $__empty_2 = true; $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <li>
                                    <div class="comments-box">
                                        <div class="comments-avatar">
                                            <img src="<?php echo e(asset('/template/assets/img/User-avatar.png')); ?>" alt="img">
                                        </div>
                                        <div class="comments-text">
                                            <div class="avatar-name">
                                                <h6 class="name"><?php echo e($reply->user ? $reply->user->name : 'Người dùng ẩn danh'); ?></h6>
                                                <span class="date"><?php echo e($reply->created_at->locale('vi')->translatedFormat('d F, Y')); ?></span>
                                            </div>
                                            <p><?php echo e($reply->content); ?></p>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <p>Chưa có trả lời nào.</p>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Chưa có bình luận nào.</p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        </div>
    </div>

    <div class="comment-respond">
        <h3 class="comment-reply-title">Gửi bình luận</h3>
        <!--[if BLOCK]><![endif]--><?php if(Auth::check()): ?>
            <form wire:submit.prevent="submitComment" class="comment-form">
                <?php echo csrf_field(); ?>
                <div class="form-grp">
                    <textarea wire:model="content" placeholder="Ý kiến của bạn"></textarea>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <button type="submit" class="btn btn-two">Gửi bình luận</button>
            </form>
        <?php else: ?>
            <p class="comment-notes">Vui lòng đăng nhập để gửi bình luận *</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\OSPanel\domains\webtintuc\resources\views/livewire/comments.blade.php ENDPATH**/ ?>