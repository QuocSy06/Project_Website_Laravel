

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-between mb-2">
                        <div class="col-auto ms-auto">
                            <form action="" class="search-bar position-relative mb-sm-0 mb-2">
                                <div class="input-group" style="border-radius: 30px; overflow: hidden;">
                                    <input type="text" class="form-control" name="key"
                                        placeholder="Tìm kiếm bình luận...">
                                    <button class="btn btn-white" type="submit" style="border-radius: 0 30px 30px 0;">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-centered table-nowrap table-borderless table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Người bình luận</th>
                                    <th>Nội dung bình luận</th>
                                    <th>Bài viết</th>
                                    <th>Ngày đăng</th>
                                    <th style="width: 82px;">Hành động</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($comment->user ? $comment->user->name : 'Người dùng ẩn danh'); ?></td>
                                        <td
                                            style="
                                max-width: 300px; 
                                overflow-wrap: break-word;
                                white-space: normal;
                            ">
                                            <?php echo e($comment->content); ?></td>
                                            <td>
                                                <?php if($comment->post): ?>
                                                <a href="<?php echo e(route('posts.show', [$comment->post->id, \Str::slug($comment->post->title)])); ?>">
                                                    <?php echo e($comment->post->title); ?>

                                                </a>
                                            <?php else: ?>
                                                Bài viết không tồn tại
                                            <?php endif; ?>
                                            </td>
                                        <td><?php echo e($comment->created_at->format('d/m/Y H:i')); ?></td>
                                        <td>
                                            <a class="btn btn-danger btn-sm" href="#"
                                                onclick="confirmDelete(event, <?php echo e($comment->id); ?>);">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            <form id="delete-form-<?php echo e($comment->id); ?>"
                                                action="<?php echo e(route('comments.destroy', $comment->id)); ?>" method="POST"
                                                style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </td>

                                        <script>
                                            function confirmDelete(event, commentId) {
                                                event.preventDefault();
                                                if (confirm('Bạn có chắc chắn muốn xóa bình luận này không?')) {
                                                    document.getElementById('delete-form-' + commentId).submit();
                                                }
                                            }
                                        </script>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        
                        <?php echo e($comments->links()); ?>

                    </div>
                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\webtintuc\resources\views/admin/comments/list.blade.php ENDPATH**/ ?>