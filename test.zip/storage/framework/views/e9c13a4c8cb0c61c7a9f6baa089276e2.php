

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-centered table-nowrap table-borderless table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Tiêu đề bài viết</th>
                                <th>Hình ảnh</th>
                                <th>Ngày đăng</th>
                                <th>Trạng thái</th>
                                <th>Chức năng</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($post->id); ?></td>
                                <td><?php echo e($post->title); ?></td>
                                <td>
                                    <img src="<?php echo e(asset($post->thumb)); ?>" alt="<?php echo e($post->name); ?>" style="
                                        width: 50px; 
                                        height: 50px;
                                        object-fit: cover; 
                                        border-radius: 5px; 
                                        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
                                        transition: transform 0.3s ease-in-out; 
                                    " onmouseover="this.style.transform='scale(1.1)'; this.style.boxShadow='0 8px 16px rgba(0, 0, 0, 0.2)';" onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 4px 8px rgba(0, 0, 0, 0.1)';">
                                </td>
                                <td><?php echo e($post->created_at->format('d-m-Y')); ?></td>
                                <td><?php echo \App\Helpers\Helper::active($post->active); ?></td>
                                <td>
                                    <a class="btn btn-primary btn-sm" href="/admin/posts/edit/<?php echo e($post->id); ?>">
                                        <i class="fas fa-edit"></i> 
                                    </a>
                                    <a class="btn btn-danger btn-sm" href="#" 
                                        onclick="removeRow(<?php echo e($post->id); ?>, '/admin/posts/destroy')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($posts->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\webtintuc\resources\views/admin/menu/posts.blade.php ENDPATH**/ ?>