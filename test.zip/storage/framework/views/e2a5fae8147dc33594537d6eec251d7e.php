<style>
    .pagination-wrap .pagination {
    gap: 6px !important;
    justify-content: center !important;
    flex-wrap: wrap !important;
}
.pagination-wrap .pagination .page-link {
    margin-left: 0 !important;
    padding: 0 0 !important;
    color: var(--tg-black-two) !important;
    font-weight: 500 !important;
    font-size: 20px !important;
    line-height: 1 !important;
    width: 40px !important;
    height: 40px !important;
    font-family: var(--tg-heading-font-family) !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    border: 1px solid #CFCFCF !important;
    border-radius: 3px !important;
    background: var(--tg-gray-three) !important;
    transition: .3s linear !important;
}
.pagination-wrap .pagination .page-item.active .page-link,
.pagination-wrap .pagination .page-link:hover {
    color: var(--tg-white);
    background-color: var(--tg-primary-color);
    border-color: var(--tg-primary-color);
}
.pagination-wrap .pagination .page-link:focus {
    color: var(--tg-white);
    background-color: var(--tg-primary-color);
    border-color: var(--tg-primary-color);
    outline: 0;
    box-shadow: none;
}
</style>
<?php if($paginator->hasPages()): ?>
    <nav aria-label="Page navigation example">
        <ul class="pagination list-wrap">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">Previous</a></li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="page-item disabled"><a class="page-link" href="#"><?php echo e($element); ?></a></li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="page-item active"><a class="page-link" href="#"><?php echo e($page); ?></a></li>
                        <?php else: ?>
                            <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Next</a></li>
            <?php else: ?>
                <li class="page-item disabled"><a class="page-link" href="#">Next</a></li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH C:\OSPanel\domains\webtintuc\resources\views/vendor/pagination/paginationClient.blade.php ENDPATH**/ ?>