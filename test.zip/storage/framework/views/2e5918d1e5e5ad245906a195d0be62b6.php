

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row justify-content-between mb-2">
                    <div class="col-auto ms-auto">
                        <form class="search-bar position-relative mb-sm-0 mb-2">
                            <input type="text" class="form-control" placeholder="Tìm kiếm...">
                            <span class="mdi mdi-magnify search-bar position-relative"></span>
                        </form>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-centered table-nowrap table-borderless table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                               
                                <th>ID</th>
                                <th>Tên bài viết</th>
                                <th>Danh mục</th>
                                <th>Update</th>
                                <th style="width: 82px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tintucs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tintuc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($tintuc->id); ?></td>
                                <td><?php echo e($tintuc->title); ?></td>
                                <td><?php echo e($tintuc->menu->name); ?></td>
                                <td><?php echo e(\App\Helpers\Helper::active($tintuc->active)); ?></td>
                                <td><?php echo e($tintuc->updated_at); ?></td>
                                <td>
                                    <a class="btn btn-primary btn-sm" href="/admin/tintuc/edit/<?php echo e($tintuc->id); ?>">
                                        <i class="fas fa-edit"></i> 
                                    </a>
                                    <a class="btn btn-danger btn-sm" href="#" onclick="removeRow(<?php echo e($tintuc->id); ?>, \'/admin/tintuc/destroy\')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            { !! $tintuc->links() !!}
                        </tbody>
                    </table>
                </div>

                

                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\webtintuc\resources\views/admin/tintuc/list.blade.php ENDPATH**/ ?>